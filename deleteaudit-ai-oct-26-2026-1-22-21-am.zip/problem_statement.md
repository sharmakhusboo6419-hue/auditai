# Problem Statement: AI-Powered Deletion Audit Agent

## Overview
Modern data architectures replicate user personal identifiable information (PII) across dozens of distributed systems: primary operational databases, search indices, analytics data warehouses, CRM systems, customer support tickets, application log files, cold backups, automated sync pipelines, and multimedia attachment stores.

When a user submits a GDPR Article 17 ("Right to Erasure") or CCPA deletion request, organizations struggle to verify whether deletion was truly completed, whether shadow copies remain, and whether automated synchronization pipelines or backup restoration jobs will inadvertently resurrect the deleted user data.

The **Deletion Audit Agent** is an autonomous, hybrid deterministic-and-AI system that audits deletion requests against distributed corporate data systems, evaluates compliance against organizational deletion rules, discovers hidden identity links, detects active recreation vectors, and synthesizes prioritized, ordered remediation steps.

---

## Output CSV Specification (`output.csv`)

The audit results must be written to `output.csv` matching this exact schema:

| Column | Type | Allowed Values / Format | Description |
| :--- | :--- | :--- | :--- |
| `request_id` | string | e.g. `DEL-101` | Unique ID of the deletion request from `deletion_requests.csv`. |
| `user_id` | string | e.g. `USR-101` | The target user identifier. |
| `status` | string | `COMPLETE` \| `INCOMPLETE` \| `NOT_APPLICABLE` | The audited status of the deletion request. |
| `exposing_records` | string | Semicolon-delimited list of records in format `system:record_id:identifier:record_type` (e.g. `analytics:EVT-902:alice@example.com:event_log;crm:LEAD-401:usr_101:lead_profile`), or `NONE` if none. | Records or identifiers across systems that still expose the user or violate retention policies. |
| `recreation_processes` | string | Semicolon-delimited list of process IDs in format `process_id:source->target` (e.g. `SYNC-01:crm_leads->primary_db;JOB-04:cold_backup->analytics_dw`), or `NONE` if none. | Active sync, import, replication, or restore processes capable of resurrecting deleted data. |
| `remediation_steps` | string | Semicolon-delimited, strictly ordered remediation steps (or verification checks if status is `COMPLETE`). | Step-by-step ordered remediation actions following the required ordering hierarchy. |
| `explanation` | string | Human-readable explanation text | Clear, objective explanation of the audit findings, rule evaluations, and reasoning. |

---

## Status Definitions

1. **`NOT_APPLICABLE`**:
   The user never submitted a deletion request, or the request was cancelled, withdrawn, or has no valid active deletion mandate in `deletion_requests.csv`.

2. **`COMPLETE`**:
   ALL of the following four criteria hold simultaneously:
   - **Rule Treatment:** Every relevant record copy received the exact treatment mandated by `deletion_rules.csv` (`delete`, `redact`, `anonymize`, or conditional retention).
   - **No Active Recreation Path:** No active sync job, scheduled import, or restore pipeline exists that sources from an untreated or stale upstream copy and targets active stores.
   - **Only Permitted Identifiers:** Any legitimately retained record (such as statutory financial audit or tax invoice) contains **only** identifiers permitted by policy (e.g., tokenized transaction ID, anonymized ledger reference; no raw emails, phones, or names).
   - **Mandatory Retained Records Exist:** Any records legally required to be retained (e.g. statutory billing archives) still exist and were not unlawfully destroyed.

3. **`INCOMPLETE`**:
   A valid deletion request exists, but one or more of the criteria above fail:
   - Untreated copies remain in primary, secondary, logs, archives, backups, or media attachments.
   - Active sync/restore processes threaten to recreate deleted data.
   - Retained records contain forbidden PII identifiers.
   - Mandatory retained records are missing.

---

## Remediation Step Ordering Principle
When a request is `INCOMPLETE`, remediation steps must strictly follow this dependency order:
1. **Phase 1: Disable Recreation Vectors** — Stop/pause all active sync, import, or restore jobs that source from stale data.
2. **Phase 2: Treat Operational & Secondary Stores** — Remove, redact, or anonymize copies in primary databases, caches, CRM leads, and search indices.
3. **Phase 3: Treat Logs & Cold Archives** — Purge or scrub PII in access logs, customer support tickets, analytics warehouses, and multimedia attachments.
4. **Phase 4: Backup Hygiene** — Flag or treat backup snapshots according to deletion rules (tombstoning, key shredding, or delta expiration).
5. **Phase 5: Retention Rectification** — Ensure mandatory statutory records are preserved while scrubbing any forbidden identifiers.
6. **Phase 6: Verification & Validation** — Execute end-to-end verification scans across all identifiers to confirm zero exposure.

*Note: For `COMPLETE` requests, output only the Verification Checks (Phase 6) demonstrating proof of compliance.*
