import os
import json
import hashlib
import time
import urllib.request
import urllib.error
from typing import Dict, List, Set, Optional, Tuple
try:
    from .config import GEMINI_API_KEY, DEFAULT_MODEL, CACHE_FILE_PATH, MAX_RETRIES, RETRY_DELAY_SEC
except ImportError:
    from config import GEMINI_API_KEY, DEFAULT_MODEL, CACHE_FILE_PATH, MAX_RETRIES, RETRY_DELAY_SEC

class MediaReader:
    """
    Handles extraction of text from local media files (text attachments, scans, images, documents)
    using configurable OCR/VLM with disk caching and retry logic.
    """
    def __init__(self, api_key: str = GEMINI_API_KEY, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self.cache: Dict[str, str] = self._load_cache()

    def _load_cache(self) -> Dict[str, str]:
        if os.path.exists(CACHE_FILE_PATH):
            try:
                with open(CACHE_FILE_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_cache(self):
        try:
            with open(CACHE_FILE_PATH, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, indent=2)
        except Exception as e:
            print(f"[WARN] Failed to write cache: {e}")

    def extract_text(self, file_path: str, fallback_text: Optional[str] = None) -> str:
        """
        Extracts all textual content from a local media file.
        """
        if not file_path:
            return fallback_text or ""

        # Normalize relative path
        if not os.path.isabs(file_path):
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            full_path = os.path.join(base_dir, file_path)
            if not os.path.exists(full_path):
                # Try in dataset/media or data/media
                full_path = os.path.join(base_dir, "dataset", "media", os.path.basename(file_path))
        else:
            full_path = file_path

        # If plain text file
        if full_path.endswith((".txt", ".json", ".csv", ".log", ".md")):
            if os.path.exists(full_path):
                try:
                    with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                        return f.read()
                except Exception as e:
                    print(f"[WARN] Error reading text file {full_path}: {e}")

        # If cache contains text for this path
        cache_key = f"media_ocr:{os.path.basename(file_path)}"
        if cache_key in self.cache:
            return self.cache[cache_key]

        # If a pre-extracted text fallback exists in dataset metadata
        if fallback_text and fallback_text.strip():
            self.cache[cache_key] = fallback_text.strip()
            self._save_cache()
            return fallback_text.strip()

        # If it is an image or PDF and GEMINI_API_KEY is configured
        if self.api_key and os.path.exists(full_path):
            extracted = self._call_vlm(full_path)
            if extracted:
                self.cache[cache_key] = extracted
                self._save_cache()
                return extracted

        return fallback_text or ""

    def _call_vlm(self, image_path: str) -> str:
        """
        Calls Gemini VLM via REST API with exponential backoff retries.
        """
        try:
            with open(image_path, "rb") as f:
                import base64
                img_b64 = base64.b64encode(f.read()).decode("utf-8")
        except Exception as e:
            print(f"[WARN] Could not read image {image_path}: {e}")
            return ""

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        payload = {
            "contents": [{
                "parts": [
                    {"text": "Extract all text, names, emails, phones, and identifiers from this document image. Return only the extracted text."},
                    {"inline_data": {"mime_type": "image/png", "data": img_b64}}
                ]
            }]
        }

        for attempt in range(MAX_RETRIES):
            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    candidates = data.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        if parts:
                            return parts[0].get("text", "")
            except Exception as e:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY_SEC * (2 ** attempt))
                else:
                    print(f"[WARN] VLM OCR API call failed after {MAX_RETRIES} attempts: {e}")
        return ""

    def scan_for_identifiers(self, text: str, identifiers: Set[str]) -> List[Tuple[str, str]]:
        """
        Scans extracted text for matches against the user's identifier set.
        Returns list of (matched_identifier, snippet).
        """
        matches = []
        lower_text = text.lower()
        for ident in identifiers:
            str_id = str(ident).strip()
            if not str_id or len(str_id) < 3:
                continue
            if str_id.lower() in lower_text:
                # Find context snippet
                idx = lower_text.find(str_id.lower())
                start = max(0, idx - 30)
                end = min(len(text), idx + len(str_id) + 30)
                snippet = text[start:end].replace("\n", " ")
                matches.append((str_id, snippet))
        return matches
