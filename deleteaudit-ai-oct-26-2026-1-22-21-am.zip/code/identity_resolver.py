import re
from typing import Dict, Set, List, Tuple, Any
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series

def normalize_email(email: str) -> List[str]:
    email = email.strip().lower()
    if not email or "@" not in email:
        return []
    variants = [email]
    # Check for plus tagging e.g. julia+newsletter@example.net -> julia@example.net
    parts = email.split("@", 1)
    if len(parts) == 2:
        user_part, domain_part = parts
        if "+" in user_part:
            base_user = user_part.split("+", 1)[0]
            base_email = f"{base_user}@{domain_part}"
            variants.append(base_email)
    return variants

def normalize_phone(phone: str) -> List[str]:
    raw = phone.strip()
    if not raw:
        return []
    variants = [raw]
    # Digits only
    digits = re.sub(r"[^\d]", "", raw)
    if digits:
        variants.append(digits)
        # If has leading country code '1', also include 10 digits
        if digits.startswith("1") and len(digits) == 11:
            variants.append(digits[1:])
    return variants

class IdentityResolver:
    """
    Builds the transitive closure of all identifiers belonging to a user across
    primary profiles, merge histories, email changes, phone changes, aliases,
    and linked identities.
    """
    def __init__(self, users_df: pd.DataFrame, links_df: pd.DataFrame):
        self.users_df = users_df
        self.links_df = links_df

    def resolve_user_identifiers(self, user_id: str) -> Dict[str, Any]:
        """
        Returns a dictionary containing:
        - user_id: str
        - identifiers: Set[str] (all normalized strings to search for)
        - identifier_map: Dict[str, str] (maps each search term to its category)
        - profile: Dict[str, str] (primary profile fields if found)
        """
        target_uid = str(user_id).strip()
        resolved_identifiers: Set[str] = set()
        identifier_categories: Dict[str, str] = {}
        primary_profile: Dict[str, str] = {}

        if target_uid:
            resolved_identifiers.add(target_uid)
            resolved_identifiers.add(target_uid.lower())
            identifier_categories[target_uid] = "user_id"
            identifier_categories[target_uid.lower()] = "user_id"

        # 1. Inspect primary users table
        if not self.users_df.empty:
            # Check user_id column
            uid_col = next((c for c in self.users_df.columns if "user_id" in c.lower() or c.lower() == "id"), None)
            if uid_col:
                matched_user = self.users_df[self.users_df[uid_col].astype(str).str.strip().str.lower() == target_uid.lower()]
                if not matched_user.empty:
                    row = matched_user.iloc[0].to_dict()
                    primary_profile = {str(k): str(v) for k, v in row.items()}
                    for col, val in row.items():
                        sval = str(val).strip()
                        if not sval or sval.lower() in {"none", "null", "nan", ""}:
                            continue
                        col_l = col.lower()
                        if "email" in col_l:
                            for ev in normalize_email(sval):
                                resolved_identifiers.add(ev)
                                identifier_categories[ev] = "email"
                        elif "phone" in col_l or "mobile" in col_l:
                            for pv in normalize_phone(sval):
                                resolved_identifiers.add(pv)
                                identifier_categories[pv] = "phone"
                        elif "name" in col_l and "user" not in col_l:
                            resolved_identifiers.add(sval)
                            resolved_identifiers.add(sval.lower())
                            identifier_categories[sval] = "name"
                        elif "username" in col_l or "handle" in col_l or "alias" in col_l:
                            resolved_identifiers.add(sval)
                            resolved_identifiers.add(sval.lower())
                            identifier_categories[sval] = "username"

        # 2. Transitive graph traversal over identity_links.csv
        # Follow links until fixed point (no new identifiers discovered)
        if not self.links_df.empty:
            queue_users = [target_uid]
            visited_users = {target_uid.lower()}

            # Columns in links table for identifier values (exclude type columns)
            user_cols = [c for c in self.links_df.columns if "user" in c.lower()]
            id_val_cols = [c for c in self.links_df.columns if "value" in c.lower() or (c.lower() in {"identifier", "linked_identifier", "val"} and "type" not in c.lower())]

            generic_words = {"email", "phone", "name", "address", "user_id", "type", "link", "true", "false", "active", "deleted", "none", "null", "usr"}

            while queue_users:
                curr_u = queue_users.pop(0)
                # Find all link rows matching curr_u in any user-like column
                mask = pd.Series([False] * len(self.links_df))
                for uc in user_cols:
                    mask = mask | (self.links_df[uc].astype(str).str.strip().str.lower() == curr_u.lower())

                matched_links = self.links_df[mask]
                for _, link_row in matched_links.iterrows():
                    # Extract identifier value
                    for ivc in id_val_cols:
                        raw_val = str(link_row.get(ivc, "")).strip()
                        if not raw_val or raw_val.lower() in generic_words:
                            continue
                        
                        link_type = str(link_row.get("link_type", link_row.get("identifier_type", "linked_id"))).lower()
                        
                        if "@" in raw_val:
                            for ev in normalize_email(raw_val):
                                resolved_identifiers.add(ev)
                                identifier_categories[ev] = "email"
                        elif re.search(r"\d{3,}", raw_val) and ("phone" in link_type or "+" in raw_val):
                            for pv in normalize_phone(raw_val):
                                resolved_identifiers.add(pv)
                                identifier_categories[pv] = "phone"
                        else:
                            resolved_identifiers.add(raw_val)
                            resolved_identifiers.add(raw_val.lower())
                            identifier_categories[raw_val] = link_type

                    # If this link points to another user_id (e.g. account merge)
                    for uc in user_cols:
                        other_uid = str(link_row.get(uc, "")).strip()
                        if other_uid and other_uid.lower() not in visited_users and other_uid.lower().startswith("usr"):
                            visited_users.add(other_uid.lower())
                            queue_users.append(other_uid)
                            resolved_identifiers.add(other_uid)
                            resolved_identifiers.add(other_uid.lower())
                            identifier_categories[other_uid] = "merged_user_id"

        return {
            "user_id": target_uid,
            "identifiers": resolved_identifiers,
            "identifier_categories": identifier_categories,
            "profile": primary_profile
        }
