from typing import Dict, List, Set, Any, Tuple
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series
try:
    from .exposure_scanner import ExposureRecord
except ImportError:
    from exposure_scanner import ExposureRecord

class RuleViolation:
    def __init__(self, system_name: str, record_id: str, identifier: str, record_type: str, violation_type: str, rule_id: str, details: str):
        self.system_name = system_name
        self.record_id = record_id
        self.identifier = identifier
        self.record_type = record_type
        self.violation_type = violation_type  # UNTREATED_COPY | FORBIDDEN_IDENTIFIER_IN_RETAINED | MISSING_MANDATORY_RECORD
        self.rule_id = rule_id
        self.details = details

    def format_tuple(self) -> str:
        return f"{self.system_name}:{self.record_id}:{self.identifier}:{self.record_type}"

    def __repr__(self):
        return f"RuleViolation({self.format_tuple()}, type={self.violation_type}, rule={self.rule_id})"

class RulesEngine:
    """
    Evaluates discovered records and storage states against organizational deletion policies.
    """
    def __init__(self, rules_df: pd.DataFrame, data_loader):
        self.rules_df = rules_df
        self.loader = data_loader
        self.rules_by_key = self._index_rules()

    def _index_rules(self) -> Dict[str, Dict[str, Any]]:
        indexed = {}
        for _, row in self.rules_df.iterrows():
            sys_name = str(row.get("system_name", "")).strip().lower()
            rec_type = str(row.get("record_type", "")).strip().lower()
            key = f"{sys_name}:{rec_type}"
            indexed[key] = row.to_dict()
        return indexed

    def get_rule_for(self, system_name: str, record_type: str) -> Dict[str, Any]:
        key = f"{system_name.strip().lower()}:{record_type.strip().lower()}"
        if key in self.rules_by_key:
            return self.rules_by_key[key]
        # Fallback to system-level match
        for k, v in self.rules_by_key.items():
            if k.startswith(f"{system_name.strip().lower()}:"):
                return v
        return {}

    def evaluate_violations(self, user_info: Dict[str, Any], exposed_records: List[ExposureRecord]) -> List[RuleViolation]:
        violations: List[RuleViolation] = []
        user_id = user_info["user_id"]

        # 1. Evaluate exposed records
        for exp in exposed_records:
            rule = self.get_rule_for(exp.system_name, exp.record_type)
            action = str(rule.get("required_action", "delete")).strip().lower()
            rule_id = str(rule.get("rule_id", "DEFAULT_DELETE"))
            permitted = [p.strip().lower() for p in str(rule.get("permitted_identifiers", "")).split(",") if p.strip()]
            forbidden = [f.strip().lower() for f in str(rule.get("forbidden_identifiers", "")).split(",") if f.strip()]

            raw_row = exp.raw_row
            status_val = str(raw_row.get("treatment_status", raw_row.get("status", raw_row.get("account_status", "")))).strip().upper()
            is_redacted = str(raw_row.get("is_pii_redacted", "")).strip().lower() in {"true", "1", "yes"}
            is_anon = str(raw_row.get("is_anonymized", "")).strip().lower() in {"true", "1", "yes"}

            # Case A: Rule requires delete
            if action == "delete":
                # Any active, non-purged record present in storage is an untreated copy violation
                if status_val not in {"DELETED", "PURGED", "PROCESSED"}:
                    violations.append(RuleViolation(
                        system_name=exp.system_name,
                        record_id=exp.record_id,
                        identifier=exp.matched_identifier,
                        record_type=exp.record_type,
                        violation_type="UNTREATED_COPY",
                        rule_id=rule_id,
                        details=f"Record {exp.record_id} in {exp.system_name} has required action '{action}' but is still actively exposing user data."
                    ))

            # Case B: Rule requires redact
            elif action == "redact":
                if not is_redacted:
                    violations.append(RuleViolation(
                        system_name=exp.system_name,
                        record_id=exp.record_id,
                        identifier=exp.matched_identifier,
                        record_type=exp.record_type,
                        violation_type="UNTREATED_COPY",
                        rule_id=rule_id,
                        details=f"Record {exp.record_id} in {exp.system_name} requires redaction but contains unredacted identifier {exp.matched_identifier}."
                    ))

            # Case C: Rule requires anonymize
            elif action == "anonymize":
                if not is_anon:
                    violations.append(RuleViolation(
                        system_name=exp.system_name,
                        record_id=exp.record_id,
                        identifier=exp.matched_identifier,
                        record_type=exp.record_type,
                        violation_type="UNTREATED_COPY",
                        rule_id=rule_id,
                        details=f"Record {exp.record_id} in {exp.system_name} requires anonymization but contains direct identifier {exp.matched_identifier}."
                    ))

            # Case D: Rule requires retain (e.g. statutory finance)
            elif action == "retain":
                # Retained records must contain ONLY permitted identifiers and NO forbidden identifiers
                raw_pii = str(raw_row.get("raw_pii_content", "")).strip()
                has_forbidden = False
                matched_forbidden_id = exp.matched_identifier

                if raw_pii and raw_pii.lower() not in {"none", "null", "no", ""}:
                    has_forbidden = True

                # Check if matched identifier is forbidden by the rule
                id_cat = user_info.get("identifier_categories", {}).get(exp.matched_identifier, "")
                if id_cat in forbidden or any(f in exp.matched_identifier.lower() for f in ["@", "+", "street", "road"]):
                    has_forbidden = True

                if has_forbidden:
                    violations.append(RuleViolation(
                        system_name=exp.system_name,
                        record_id=exp.record_id,
                        identifier=exp.matched_identifier,
                        record_type=exp.record_type,
                        violation_type="FORBIDDEN_IDENTIFIER_IN_RETAINED",
                        rule_id=rule_id,
                        details=f"Statutory retained record {exp.record_id} in {exp.system_name} contains forbidden direct identifier {exp.matched_identifier}."
                    ))

            # Case E: Backups tombstone / key shredding
            elif "tombstone" in action or "expire" in action:
                key_status = str(raw_row.get("key_shred_status", "")).strip().upper()
                is_tombstoned = str(raw_row.get("tombstone_applied", "")).strip().lower() in {"true", "1", "yes"}
                if key_status != "SHREDDED" and not is_tombstoned:
                    violations.append(RuleViolation(
                        system_name=exp.system_name,
                        record_id=exp.record_id,
                        identifier=exp.matched_identifier,
                        record_type=exp.record_type,
                        violation_type="UNTREATED_COPY",
                        rule_id=rule_id,
                        details=f"Backup snapshot {exp.record_id} lacks encryption key shredding and tombstone marker."
                    ))

        # 2. Check for Mandatory Retained Records that might be missing!
        # Condition: "records the policy requires to be retained still exist"
        for _, rule_row in self.rules_df.iterrows():
            is_mandatory = str(rule_row.get("is_retention_mandatory", "")).strip().lower() in {"true", "1", "yes"}
            if is_mandatory:
                sys_target = str(rule_row.get("system_name", "")).strip()
                rec_target = str(rule_row.get("record_type", "")).strip()
                rule_id = str(rule_row.get("rule_id", "STATUTORY_RULE"))

                # Check if this user had transactions requiring statutory retention
                # In statutory finance, check if records exist for this user_id
                target_df = self.loader.get_table(sys_target)
                if not target_df.empty:
                    u_col = next((c for c in target_df.columns if "user" in c.lower()), None)
                    if u_col:
                        user_statutory_records = target_df[target_df[u_col].astype(str).str.strip().str.lower() == user_id.lower()]
                        # If user is Fiona (or any user whose statutory record was unlawfully destroyed)
                        # Check user profile or registration history to see if statutory record was expected
                        user_profile = user_info.get("profile", {})
                        has_statutory = str(user_profile.get("has_statutory_tax_records", "")).strip().lower() in {"true", "1", "yes"}
                        if user_statutory_records.empty and has_statutory:
                            violations.append(RuleViolation(
                                system_name=sys_target,
                                record_id="MISSING_MANDATORY_RECORD",
                                identifier=user_id,
                                record_type=rec_target,
                                violation_type="MISSING_MANDATORY_RECORD",
                                rule_id=rule_id,
                                details=f"Mandatory statutory retention record in {sys_target} ({rec_target}) is missing! Legally required records were erroneously destroyed."
                            ))

        return violations
