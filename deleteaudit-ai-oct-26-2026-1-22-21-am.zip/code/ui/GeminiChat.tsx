import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../src/context/AuthContext';
import { db } from '../../src/lib/firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  modelUsed?: string;
  roleUsed?: string;
}

export type ModelOption = 'gemini-4-argon' | 'gemini-3.8-flash' | 'gemini-3.1-flash-lite';

export interface RolePreset {
  id: string;
  name: string;
  model: ModelOption;
  description: string;
  systemInstruction: string;
}

const ROLE_PRESETS: RolePreset[] = [
  {
    id: 'general',
    name: 'General Compliance Auditor',
    model: 'gemini-3.8-flash',
    description: 'General compliance reasoning, remediation guidance & erasure verification.',
    systemInstruction:
      'You are the Senior Deletion Compliance & Audit Assistant. Help the compliance team verify erasure status, identify lingering PII records, evaluate active recreation pipelines, and navigate the 6-phase remediation lifecycle.'
  },
  {
    id: 'complex',
    name: 'Deep Legal & Risk Auditor',
    model: 'gemini-4-argon',
    description: 'Complex legal analysis, statutory exemptions, cross-system race conditions & risk modeling.',
    systemInstruction:
      'You are a Senior Data Privacy Legal Counsel & Systems Risk Auditor. Analyze GDPR Article 17, CCPA, statutory exemptions, active ETL sync vectors, and cryptographic key-shredding requirements. Deliver exhaustive, rigorous, audit-grade technical and legal explanations.'
  },
  {
    id: 'fast',
    name: 'Fast Triage Copilot',
    model: 'gemini-3.1-flash-lite',
    description: 'Fast lookups, quick identifier cross-checks & rapid status triage.',
    systemInstruction:
      'You are a Fast Triage Assistant for the Deletion Audit Agent. Provide immediate, concise answers, specific identifier lookups, and clear bullet points on remediation steps.'
  }
];

interface GeminiChatProps {
  selectedRequestId?: string;
  onClose?: () => void;
}

export default function GeminiChat({ selectedRequestId, onClose }: GeminiChatProps) {
  const { user } = useAuth();
  const [selectedPresetId, setSelectedPresetId] = useState<string>('general');
  const [customInstruction, setCustomInstruction] = useState<string>('');
  const [showPromptSettings, setShowPromptSettings] = useState<boolean>(false);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);

  const activePreset = ROLE_PRESETS.find((p) => p.id === selectedPresetId) || ROLE_PRESETS[0];

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content: `Compliance Copilot online. Active role: ${activePreset.name} (powered by ${activePreset.model}).\n\nI can analyze deletion requests (DEL-001 through DEL-010), investigate residual PII exposures, or trace recreation pipelines. How can I assist your audit?`,
      timestamp: new Date().toISOString(),
      modelUsed: activePreset.model,
      roleUsed: activePreset.name
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load chat history from Firestore if available
  useEffect(() => {
    if (!user || user.uid === 'guest-auditor-session') return;
    const threadRef = doc(db, 'users', user.uid, 'chatThreads', 'audit-copilot-thread');
    getDoc(threadRef)
      .then((snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (Array.isArray(data?.messages) && data.messages.length > 0) {
            setMessages(data.messages);
          }
        }
      })
      .catch((err) => {
        console.warn('Chat thread load notice:', err);
      });
  }, [user]);

  // Save chat history to Firestore
  const persistMessages = async (updated: ChatMessage[]) => {
    if (!user || user.uid === 'guest-auditor-session') return;
    try {
      const threadRef = doc(db, 'users', user.uid, 'chatThreads', 'audit-copilot-thread');
      await setDoc(
        threadRef,
        {
          threadId: 'audit-copilot-thread',
          userId: user.uid,
          role: activePreset.name,
          model: activePreset.model,
          messages: updated.slice(-30), // keep recent turns
          updatedAt: new Date().toISOString()
        },
        { merge: true }
      );
    } catch (err) {
      console.warn('Failed to persist chat thread', err);
    }
  };

  const handleSend = async (contentToSend?: string) => {
    const text = (contentToSend || inputMessage).trim();
    if (!text || isSending) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString()
    };

    const newThread = [...messages, userMsg];
    setMessages(newThread);
    setInputMessage('');
    setIsSending(true);

    try {
      // Call server proxy with multi-turn history
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newThread.map((m) => ({ role: m.role, content: m.content })),
          model: activePreset.model,
          role: activePreset.name,
          customInstruction: customInstruction.trim(),
          selectedRequestId: selectedRequestId || ''
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}`);
      }

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        content: data.text || 'No response returned.',
        timestamp: new Date().toISOString(),
        modelUsed: data.modelUsed || activePreset.model,
        roleUsed: data.roleUsed || activePreset.name
      };

      const finalThread = [...newThread, assistantMsg];
      setMessages(finalThread);
      persistMessages(finalThread);
    } catch (err: any) {
      console.error('Chat request failed', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `Notice: Upstream AI API connection error (${err?.message || 'unknown'}). Please verify server connectivity or try again.`,
        timestamp: new Date().toISOString(),
        modelUsed: activePreset.model
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const clearChat = () => {
    const resetThread: ChatMessage[] = [
      {
        id: `init-${Date.now()}`,
        role: 'assistant',
        content: `Chat history cleared. Active role: ${activePreset.name} (${activePreset.model}). Ready for new audit queries.`,
        timestamp: new Date().toISOString(),
        modelUsed: activePreset.model,
        roleUsed: activePreset.name
      }
    ];
    setMessages(resetThread);
    persistMessages(resetThread);
  };

  const quickPrompts = [
    selectedRequestId
      ? `Audit summary for ${selectedRequestId}`
      : 'Why is DEL-001 INCOMPLETE?',
    'What active sync pipelines threaten deletion?',
    'Explain the 6-phase remediation lifecycle',
    'Why must Fiona (USR-106) statutory records be retained?'
  ];

  return (
    <div className="flex flex-col h-full bg-[#0d1117] border border-[#1c222b] rounded-sm text-xs font-sans">
      {/* Chat Header */}
      <div className="px-3 py-2 bg-[#13171f] border-b border-[#1c222b] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="font-semibold text-white tracking-tight text-xs">
            Gemini Compliance Copilot
          </span>
          <span className="text-[#64748b]">|</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-xs bg-[#161a22] text-[#93c5fd] border border-[#3b82f6]/30">
            {activePreset.model}
          </span>
          {selectedRequestId && (
            <span className="font-mono text-[10px] text-[#fcd34d] px-1 py-0.2 bg-[#451a03]/20 border border-[#d97706]/40 rounded-xs">
              Focused on {selectedRequestId}
            </span>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowPromptSettings(!showPromptSettings)}
            className="text-[10px] text-[#8b949e] hover:text-white transition font-mono cursor-pointer"
          >
            {showPromptSettings ? 'Hide Role Config' : 'Configure Role'}
          </button>
          <button
            onClick={clearChat}
            className="text-[10px] text-[#64748b] hover:text-[#c9d1d9] transition font-mono cursor-pointer"
            title="Clear message history"
          >
            Clear
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="text-[#8b949e] hover:text-white text-xs ml-1 cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Role & System Instruction Settings Drawer */}
      {showPromptSettings && (
        <div className="p-3 bg-[#10141a] border-b border-[#1c222b] space-y-2.5">
          <div>
            <div className="text-[11px] font-semibold text-white uppercase tracking-wider mb-1">
              Select Chatbot Role & Model
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {ROLE_PRESETS.map((p) => {
                const isSelected = p.id === selectedPresetId;
                return (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPresetId(p.id)}
                    className={`p-2 rounded-sm border text-left transition cursor-pointer ${
                      isSelected
                        ? 'bg-[#1e2633] border-[#3b82f6] text-white'
                        : 'bg-[#161a22] border-[#21262d] text-[#8b949e] hover:text-[#c9d1d9]'
                    }`}
                  >
                    <div className="font-semibold text-[11px] flex items-center justify-between">
                      <span>{p.name}</span>
                      <span className="font-mono text-[9px] px-1 bg-[#090c0f] rounded-xs text-[#93c5fd]">
                        {p.model}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#64748b] mt-1 leading-snug">
                      {p.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-mono text-[#8b949e]">
                Active System Instruction (Role Prompt):
              </span>
              <span className="text-[9px] text-[#64748b]">Customizable</span>
            </div>
            <textarea
              rows={2}
              value={customInstruction || activePreset.systemInstruction}
              onChange={(e) => setCustomInstruction(e.target.value)}
              className="w-full bg-[#090c0f] border border-[#21262d] rounded-sm p-1.5 text-[10px] font-mono text-[#c9d1d9] focus:outline-none focus:border-[#3b82f6]"
            />
          </div>
        </div>
      )}

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 max-h-[460px]">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={m.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center space-x-1.5 mb-1 px-1">
                <span className="font-mono text-[10px] font-semibold text-[#8b949e]">
                  {isUser ? (user?.email || 'You (Auditor)') : 'Gemini Copilot'}
                </span>
                {!isUser && m.modelUsed && (
                  <span className="font-mono text-[9px] px-1 py-0.2 bg-[#161a22] rounded-xs text-[#93c5fd] border border-[#21262d]">
                    {m.modelUsed}
                  </span>
                )}
                <span className="font-mono text-[9px] text-[#64748b]">
                  {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              <div
                className={`p-2.5 rounded-sm max-w-[88%] text-[11px] leading-relaxed whitespace-pre-wrap ${
                  isUser
                    ? 'bg-[#1e2633] border border-[#3b82f6]/40 text-white'
                    : 'bg-[#11151b] border border-[#1c222b] text-[#c9d1d9]'
                }`}
              >
                {m.content}
              </div>
            </div>
          );
        })}

        {isSending && (
          <div className="flex items-center space-x-2 text-[#8b949e] font-mono text-[10px] py-1 px-2">
            <span className="inline-block w-2 h-2 rounded-full bg-[#3b82f6] animate-pulse" />
            <span>Gemini ({activePreset.model}) is formulating audit analysis...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="px-3 py-1.5 bg-[#10141a] border-t border-[#1c222b] flex items-center space-x-1.5 overflow-x-auto">
        <span className="text-[10px] font-mono text-[#64748b] whitespace-nowrap">Suggested:</span>
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(qp)}
            disabled={isSending}
            className="px-2 py-0.5 rounded-xs bg-[#161a22] hover:bg-[#1e2633] text-[#8b949e] hover:text-[#93c5fd] border border-[#21262d] text-[10px] font-mono whitespace-nowrap transition cursor-pointer disabled:opacity-50"
          >
            {qp}
          </button>
        ))}
      </div>

      {/* Chat Input Form */}
      <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="p-2.5 bg-[#13171f] border-t border-[#1c222b] flex items-center space-x-2">
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder={`Ask ${activePreset.name} (${activePreset.model})...`}
          disabled={isSending}
          className="flex-1 px-3 py-1.5 text-xs bg-[#090c0f] border border-[#21262d] rounded-sm text-white placeholder-[#64748b] focus:outline-none focus:border-[#3b82f6]"
        />
        <button
          type="submit"
          disabled={isSending || !inputMessage.trim()}
          className="px-3.5 py-1.5 rounded-sm bg-[#1e2633] hover:bg-[#253245] text-[#93c5fd] border border-[#3b82f6]/40 font-medium text-xs transition cursor-pointer disabled:opacity-50"
        >
          {isSending ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
