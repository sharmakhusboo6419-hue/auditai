import React, { useState, useEffect } from 'react';
import { useAuth } from '../../src/context/AuthContext';
import firebaseConfig from '../../firebase-applet-config.json';

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  size?: string;
  modifiedTime?: string;
}

interface GoogleDriveManagerProps {
  selectedRequestId?: string;
  onClose?: () => void;
}

export default function GoogleDriveManager({ selectedRequestId, onClose }: GoogleDriveManagerProps) {
  const { user } = useAuth();
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const clientId = firebaseConfig.oAuthClientId || '';
  const scopes = 'https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly';

  // Request token using Google Identity Services (GIS) token client
  const requestDriveToken = () => {
    setError(null);
    if (!clientId) {
      setError('OAuth Client ID is missing in firebase-applet-config.json');
      return;
    }

    try {
      // @ts-ignore
      if (typeof google === 'undefined' || !google.accounts || !google.accounts.oauth2) {
        setError('Google Identity Services script not loaded. Please check your network connection.');
        return;
      }

      // @ts-ignore
      const client = google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: scopes,
        callback: (response: any) => {
          if (response.error) {
            setError(`Google Drive Auth Error: ${response.error}`);
            return;
          }
          if (response.access_token) {
            setAccessToken(response.access_token);
            fetchDriveFiles(response.access_token);
          }
        },
      });

      client.requestAccessToken();
    } catch (err: any) {
      setError(`Auth initiation failed: ${err?.message || err}`);
    }
  };

  const fetchDriveFiles = async (token: string, query?: string) => {
    setLoading(true);
    setError(null);
    try {
      let url = 'https://www.googleapis.com/drive/v3/files?pageSize=25&fields=files(id,name,mimeType,webViewLink,size,modifiedTime)';
      if (query && query.trim()) {
        const qSafe = query.replace(/'/g, "\\'");
        url += `&q=name contains '${qSafe}' and trashed = false`;
      } else {
        url += '&q=trashed = false';
      }

      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error?.message || `Google Drive API error (${res.status})`);
      }

      const data = await res.json();
      setFiles(data.files || []);
    } catch (err: any) {
      setError(err?.message || 'Failed to list Google Drive files');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessToken) {
      fetchDriveFiles(accessToken, searchQuery);
    }
  };

  const uploadAuditArtifact = async () => {
    if (!accessToken) return;
    setUploading(true);
    setUploadStatus(null);
    setError(null);

    try {
      // Fetch output.csv content to upload as artifact
      const csvRes = await fetch('/output.csv');
      const csvText = await csvRes.text();
      const fileName = `Deletion_Audit_Report_${selectedRequestId || 'all'}_${Date.now()}.csv`;

      const metadata = {
        name: fileName,
        mimeType: 'text/csv',
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', new Blob([csvText], { type: 'text/csv' }));

      const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`
        },
        body: form
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error?.message || 'Failed to upload file to Google Drive');
      }

      const uploaded = await res.json();
      setUploadStatus(`Successfully uploaded artifact "${uploaded.name}" to Google Drive!`);
      fetchDriveFiles(accessToken, searchQuery);
    } catch (err: any) {
      setError(err?.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0d1117] border border-[#1c222b] rounded-sm text-xs font-sans">
      {/* Header */}
      <div className="px-3 py-2 bg-[#13171f] border-b border-[#1c222b] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="font-semibold text-white tracking-tight text-xs">
            Google Drive Compliance Vault
          </span>
          <span className="text-[#64748b]">|</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-xs bg-[#064e3b]/20 text-[#34d399] border border-[#059669]/40">
            Drive OAuth Connected
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {accessToken ? (
            <button
              onClick={() => {
                setAccessToken(null);
                setFiles([]);
              }}
              className="text-[10px] text-[#8b949e] hover:text-white font-mono cursor-pointer"
            >
              Disconnect Drive
            </button>
          ) : (
            <button
              onClick={requestDriveToken}
              className="px-2.5 py-1 bg-[#1e2633] hover:bg-[#253245] text-[#93c5fd] border border-[#3b82f6]/40 rounded-sm font-medium text-[11px] cursor-pointer"
            >
              Authorize Google Drive
            </button>
          )}
          {onClose && (
            <button onClick={onClose} className="text-[#8b949e] hover:text-white text-xs ml-1 cursor-pointer">
              ✕
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-[#451a03]/40 border-b border-[#d97706]/40 px-3 py-1.5 text-[11px] text-[#fcd34d] flex justify-between items-center">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-[#8b949e] hover:text-white">✕</button>
        </div>
      )}

      {uploadStatus && (
        <div className="bg-[#064e3b]/30 border-b border-[#059669]/40 px-3 py-1.5 text-[11px] text-[#34d399] flex justify-between items-center font-mono">
          <span>{uploadStatus}</span>
          <button onClick={() => setUploadStatus(null)} className="text-[#8b949e] hover:text-white">✕</button>
        </div>
      )}

      {/* Main Content Area */}
      {!accessToken ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3">
          <div className="text-white font-medium text-sm">Connect Google Drive to manage compliance records</div>
          <p className="text-[#8b949e] max-w-md text-[11px] leading-relaxed">
            Authorize Google Drive access to browse your cloud documents, search audit artifacts, and back up `output.csv` compliance reports directly to your Drive vault.
          </p>
          <button
            onClick={requestDriveToken}
            className="px-4 py-2 bg-[#1e2633] hover:bg-[#253245] text-white border border-[#3b82f6]/40 rounded-sm font-medium text-xs transition cursor-pointer"
          >
            Authorize Google Drive Now
          </button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden p-3 space-y-3">
          {/* Toolbar */}
          <div className="flex items-center justify-between gap-2">
            <form onSubmit={handleSearch} className="flex-1 flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Google Drive files..."
                className="flex-1 bg-[#090c0f] border border-[#21262d] rounded-sm px-2.5 py-1 text-xs text-white placeholder-[#64748b] focus:outline-none focus:border-[#3b82f6]"
              />
              <button
                type="submit"
                className="px-3 py-1 bg-[#161a22] hover:bg-[#1e2633] text-[#c9d1d9] border border-[#21262d] rounded-sm text-xs font-mono cursor-pointer"
              >
                Search
              </button>
            </form>

            <button
              onClick={uploadAuditArtifact}
              disabled={uploading}
              className="px-3 py-1 bg-[#1e2633] hover:bg-[#253245] text-[#93c5fd] border border-[#3b82f6]/40 rounded-sm text-xs font-medium font-mono cursor-pointer disabled:opacity-50 whitespace-nowrap"
            >
              {uploading ? 'Backing up...' : 'Backup output.csv to Drive'}
            </button>
          </div>

          {/* Files Table */}
          <div className="flex-1 border border-[#1c222b] bg-[#11151b] rounded-sm overflow-y-auto">
            {loading ? (
              <div className="p-6 text-center text-[#8b949e] font-mono">Loading files from Google Drive...</div>
            ) : files.length === 0 ? (
              <div className="p-6 text-center text-[#8b949e]">No files found in Google Drive matching query.</div>
            ) : (
              <table className="w-full text-left border-collapse text-[11px]">
                <thead>
                  <tr className="border-b border-[#1c222b] bg-[#13171f] text-[#8b949e]">
                    <th className="py-1.5 px-3 font-medium">File Name</th>
                    <th className="py-1.5 px-3 font-medium">Mime Type</th>
                    <th className="py-1.5 px-3 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c222b] font-mono">
                  {files.map((file) => (
                    <tr key={file.id} className="hover:bg-[#161a22]">
                      <td className="py-2 px-3 text-white font-medium truncate max-w-[240px]">
                        {file.name}
                      </td>
                      <td className="py-2 px-3 text-[#8b949e] truncate max-w-[180px]">
                        {file.mimeType}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {file.webViewLink ? (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#3b82f6] hover:underline font-mono text-[10px]"
                          >
                            Open in Drive →
                          </a>
                        ) : (
                          <span className="text-[#64748b]">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
