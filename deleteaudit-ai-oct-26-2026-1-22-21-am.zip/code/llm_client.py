import os
import json
import time
import urllib.request
import urllib.error
from typing import Dict, List, Any
try:
    from .config import GEMINI_API_KEY, DEFAULT_MODEL, CACHE_FILE_PATH, MAX_RETRIES, RETRY_DELAY_SEC, LLM_PROVIDER
except ImportError:
    from config import GEMINI_API_KEY, DEFAULT_MODEL, CACHE_FILE_PATH, MAX_RETRIES, RETRY_DELAY_SEC, LLM_PROVIDER

class LLMExplanationSynthesizer:
    """
    Synthesizes audit-grade, human-readable explanations using configurable LLM
    with disk caching and deterministic rule-engine fallback.
    Never decides the status itself; only writes readable explanations based on deterministic audit facts.
    """
    def __init__(self, api_key: str = GEMINI_API_KEY, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self.cache: Dict[str, str] = self._load_cache()

    def _load_cache(self) -> Dict[str, str]:
        if os.path.exists(CACHE_FILE_PATH):
            try:
                with open(CACHE_FILE_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_cache(self):
        try:
            with open(CACHE_FILE_PATH, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, indent=2)
        except Exception:
            pass

    def generate_explanation(self, request_id: str, user_id: str, status: str,
                             violations: List[Any],
                             recreation_procs: List[Any],
                             request_meta: Dict[str, Any]) -> str:
        cache_key = f"explanation:{request_id}:{status}:{len(violations)}:{len(recreation_procs)}"
        if cache_key in self.cache:
            return self.cache[cache_key]

        # If LLM API Key is configured and provider is gemini, call LLM
        if self.api_key and LLM_PROVIDER == "gemini":
            prompt = self._build_prompt(request_id, user_id, status, violations, recreation_procs, request_meta)
            explanation = self._call_gemini(prompt)
            if explanation:
                self.cache[cache_key] = explanation.strip()
                self._save_cache()
                return explanation.strip()

        # Deterministic rule-based template generation
        explanation = self._generate_deterministic(request_id, user_id, status, violations, recreation_procs, request_meta)
        self.cache[cache_key] = explanation
        self._save_cache()
        return explanation

    def _build_prompt(self, request_id: str, user_id: str, status: str,
                      violations: List[Any], recreation_procs: List[Any],
                      request_meta: Dict[str, Any]) -> str:
        v_summaries = [f"- System: {v.system_name}, Record: {v.record_id}, Identifier: {v.identifier}, Type: {v.violation_type}, Detail: {v.details}" for v in violations]
        p_summaries = [f"- Process: {p.process_id} ({p.process_name}), Source: {p.source_system} -> Target: {p.target_system}, Reason: {p.reason}" for p in recreation_procs]
        return f"""You are a certified Data Protection & Deletion Compliance Auditor.
Write a concise, professional audit explanation (2-4 sentences) explaining why request {request_id} for user {user_id} was determined to be {status}.

Request Metadata: {json.dumps(request_meta)}
Rule Violations Found:
{chr(10).join(v_summaries) if v_summaries else "None (all records compliant)"}

Active Recreation Vectors:
{chr(10).join(p_summaries) if p_summaries else "None (no active sync or restore vectors)"}

Ensure the explanation explicitly references any exposed systems, violating identifiers, or active recreation jobs. Do not change the status."""

    def _call_gemini(self, prompt: str) -> str:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 300}
        }
        for attempt in range(MAX_RETRIES):
            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=12) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    candidates = data.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        if parts:
                            return parts[0].get("text", "")
            except Exception as e:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY_SEC)
                else:
                    print(f"[WARN] LLM explanation generation failed: {e}")
        return ""

    def _generate_deterministic(self, request_id: str, user_id: str, status: str,
                                violations: List[Any], recreation_procs: List[Any],
                                request_meta: Dict[str, Any]) -> str:
        req_status = request_meta.get("request_status", "UNKNOWN")
        if status == "NOT_APPLICABLE":
            return f"Request {request_id} for {user_id} is NOT_APPLICABLE because the deletion request was {req_status.lower() or 'not submitted'}; no active legal erasure mandate applies."

        if status == "COMPLETE":
            return f"Audit verified deletion for {user_id} (Request {request_id}) is COMPLETE. All operational copies are purged or anonymized, no active recreation pipelines target active stores, and statutory financial records exist with permitted non-PII tokens only."

        # INCOMPLETE: summarize specific violations and recreation paths
        reasons = []
        if violations:
            v_sys = list(dict.fromkeys([v.system_name for v in violations]))
            v_types = list(dict.fromkeys([v.violation_type for v in violations]))
            reasons.append(f"{len(violations)} rule violation(s) across {', '.join(v_sys)} ({', '.join(v_types)})")

        if recreation_procs:
            p_ids = [p.process_id for p in recreation_procs]
            reasons.append(f"{len(recreation_procs)} active recreation vector(s) ({', '.join(p_ids)}) capable of resurrecting deleted data")

        return f"Request {request_id} for {user_id} is INCOMPLETE due to: {'; '.join(reasons)}. Remediation is required before certification."
