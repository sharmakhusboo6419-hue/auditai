import os

# Base paths
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATASET_DIR = os.path.join(BASE_DIR, "dataset") if os.path.isdir(os.path.join(BASE_DIR, "dataset")) else os.path.join(BASE_DIR, "data")
OUTPUT_CSV_PATH = os.path.join(BASE_DIR, "output.csv")
LOG_PATH = os.path.join(BASE_DIR, "log.txt")
CACHE_FILE_PATH = os.path.join(os.path.dirname(__file__), ".llm_cache.json")

# LLM & VLM settings
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY") or os.environ.get("LLM_API_KEY") or ""
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "deterministic_rule_engine")
DEFAULT_MODEL = os.environ.get("DEFAULT_MODEL", "gemini-3.8-flash")
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "1"))
RETRY_DELAY_SEC = float(os.environ.get("RETRY_DELAY_SEC", "0.5"))

# Schema columns expected in output.csv
EXPECTED_OUTPUT_COLUMNS = [
    "request_id",
    "user_id",
    "status",
    "exposing_records",
    "recreation_processes",
    "remediation_steps",
    "explanation"
]

ALLOWED_STATUSES = ["COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"]
