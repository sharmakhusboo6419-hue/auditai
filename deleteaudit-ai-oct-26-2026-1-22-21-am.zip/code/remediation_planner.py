from typing import List, Dict, Any
try:
    from .rules_engine import RuleViolation
    from .recreation_analyzer import RecreationProcess
except ImportError:
    from rules_engine import RuleViolation
    from recreation_analyzer import RecreationProcess

class RemediationPlanner:
    """
    Synthesizes ordered remediation plans following the strict lifecycle ordering principle:
    (a) Disable/pause active recreation processes
    (b) Treat primary operational stores & secondary search/CRM indices
    (c) Treat derived analytics, system logs, support transcripts, media attachments
    (d) Backup hygiene (tombstoning, key shredding)
    (e) Retain/rectify statutory records and strip forbidden identifiers
    (f) Verification checks proving compliance
    """
    def generate_plan(self, status: str, user_id: str, violations: List[RuleViolation], recreation_procs: List[RecreationProcess]) -> List[str]:
        if status == "NOT_APPLICABLE":
            return ["No remediation required: user has no active or submitted deletion request."]

        if status == "COMPLETE":
            # For COMPLETE cases, output ONLY the verification checks proving it
            return [
                f"Verify operational databases confirm zero records for {user_id}",
                f"Verify search index and CRM lead caches contain zero residual identifiers",
                f"Verify analytics event streams are fully pseudonymized with compliant token hashing",
                f"Verify support transcripts have PII redacted in compliance with GDPR/CCPA",
                f"Verify statutory financial tax records exist and contain only permitted non-PII tokens",
                f"Verify backup snapshots are key-shredded or tombstoned",
                f"Verify no active sync, ETL, or restore pipelines target operational stores from stale sources",
                f"Execute end-to-end multi-identifier exposure re-scan to certify full erasure"
            ]

        # Status is INCOMPLETE: Generate prioritized, ordered remediation steps
        steps: List[str] = []

        # Phase 1: Disable active recreation processes
        if recreation_procs:
            for p in recreation_procs:
                steps.append(f"1. Stop/pause active process {p.process_id} ({p.process_name}) from {p.source_system} to {p.target_system} to prevent data recreation")

        # Phase 2: Treat primary operational stores & secondary search/CRM
        p2_systems = {"primary_db", "crm_system", "search_index"}
        p2_violations = [v for v in violations if v.system_name in p2_systems and v.violation_type == "UNTREATED_COPY"]
        for v in p2_violations:
            steps.append(f"2. Remove/purge record {v.record_id} in {v.system_name} ({v.record_type}) containing exposed identifier '{v.identifier}'")

        # Phase 3: Treat derived stores, analytics, logs, support, media attachments
        p3_systems = {"analytics_dw", "support_system", "system_logs", "media_attachments"}
        p3_violations = [v for v in violations if v.system_name in p3_systems and v.violation_type == "UNTREATED_COPY"]
        for v in p3_violations:
            if v.system_name == "media_attachments":
                steps.append(f"3. Purge media attachment {v.record_id} in blob store containing exposed identifier '{v.identifier}'")
            elif v.system_name == "support_system":
                steps.append(f"3. Redact customer transcript in ticket {v.record_id} ({v.system_name})")
            elif v.system_name == "analytics_dw":
                steps.append(f"3. Anonymize event record {v.record_id} in {v.system_name} with approved token hashing")
            else:
                steps.append(f"3. Scrub log entry {v.record_id} in {v.system_name} to remove query parameter PII")

        # Phase 4: Backup hygiene
        p4_violations = [v for v in violations if v.system_name == "backups"]
        for v in p4_violations:
            steps.append(f"4. Apply key shredding and tombstone marker on backup snapshot {v.record_id}")

        # Phase 5: Preserve required retained records & strip forbidden identifiers
        p5_violations = [v for v in violations if v.system_name == "statutory_finance" or v.violation_type in {"FORBIDDEN_IDENTIFIER_IN_RETAINED", "MISSING_MANDATORY_RECORD"}]
        for v in p5_violations:
            if v.violation_type == "MISSING_MANDATORY_RECORD":
                steps.append(f"5. Restore statutory compliance record in {v.system_name} ({v.record_type}) to comply with mandatory 7-year legal retention policy")
            elif v.violation_type == "FORBIDDEN_IDENTIFIER_IN_RETAINED":
                steps.append(f"5. Strip forbidden identifiers ('{v.identifier}') from statutory invoice {v.record_id} while preserving permitted invoice and tax tokens")

        # Phase 6: Final verification checks
        steps.append(f"6. Re-scan all resolved identifiers for {user_id} across all storage tiers to verify zero exposure")
        steps.append(f"6. Confirm no active automated sync or restore path can recreate deleted records")
        steps.append(f"6. Confirm mandatory statutory records remain intact with permitted identifiers only")

        return steps
