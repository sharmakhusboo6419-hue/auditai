"""
Compatibility layer for pandas.
Uses real pandas if installed; otherwise falls back to a lightweight,
pure standard-library (csv/dict) implementation with zero external dependencies.
"""
try:
    import pandas as pd
    HAS_REAL_PANDAS = True
except ImportError:
    HAS_REAL_PANDAS = False
    import csv
    import os

    class Series:
        def __init__(self, values, name=None):
            self.values = list(values)
            self.name = name

        def __len__(self):
            return len(self.values)

        def __iter__(self):
            return iter(self.values)

        def __getitem__(self, idx):
            return self.values[idx]

        def __invert__(self):
            return Series([not bool(x) for x in self.values])

        def __and__(self, other):
            if isinstance(other, Series):
                return Series([bool(a and b) for a, b in zip(self.values, other.values)])
            return Series([bool(a and other) for a in self.values])

        def __or__(self, other):
            if isinstance(other, Series):
                return Series([bool(a or b) for a, b in zip(self.values, other.values)])
            return Series([bool(a or other) for a in self.values])

        def astype(self, _type):
            return self

        @property
        def str(self):
            class StrAccessor:
                def __init__(self, s):
                    self.s = s

                def strip(self):
                    return Series([str(x).strip() for x in self.s.values])

                def lower(self):
                    return Series([str(x).lower() for x in self.s.values])

                def upper(self):
                    return Series([str(x).upper() for x in self.s.values])

            return StrAccessor(self)

        def isin(self, collection):
            col_set = set(collection)
            return Series([x in col_set for x in self.values])

        def tolist(self):
            return list(self.values)

        def __eq__(self, other):
            if isinstance(other, Series):
                return Series([a == b for a, b in zip(self.values, other.values)])
            return Series([a == other for a in self.values])

    class DataFrame:
        def __init__(self, data=None, columns=None):
            if data is None:
                self._rows = []
                self.columns = columns or []
            elif isinstance(data, list):
                self._rows = [dict(r) for r in data]
                if columns:
                    self.columns = list(columns)
                elif self._rows:
                    self.columns = list(self._rows[0].keys())
                else:
                    self.columns = []
            elif isinstance(data, dict):
                # Dict of lists
                keys = list(data.keys())
                length = len(data[keys[0]]) if keys else 0
                self.columns = keys
                self._rows = [{k: data[k][i] for k in keys} for i in range(length)]
            else:
                self._rows = []
                self.columns = []

        @property
        def empty(self):
            return len(self._rows) == 0

        @property
        def shape(self):
            return (len(self._rows), len(self.columns))

        @property
        def iloc(self):
            class ILocIndexer:
                def __init__(self, df):
                    self.df = df

                def __getitem__(self, idx):
                    if isinstance(idx, int):
                        class RowWrapper:
                            def __init__(self, d):
                                self._d = d
                            def to_dict(self):
                                return dict(self._d)
                            def get(self, k, default=None):
                                return self._d.get(k, default)
                            def __getitem__(self, k):
                                return self._d[k]
                        return RowWrapper(self.df._rows[idx])
                    elif isinstance(idx, slice):
                        return DataFrame(self.df._rows[idx], columns=self.df.columns)
                    raise IndexError(idx)

            return ILocIndexer(self)

        def fillna(self, _val):
            return self

        def __len__(self):
            return len(self._rows)

        def __getitem__(self, key):
            if isinstance(key, Series):
                filtered = [r for r, keep in zip(self._rows, key.values) if keep]
                return DataFrame(filtered, columns=self.columns)
            if isinstance(key, list):
                sub_rows = [{k: r.get(k, "") for k in key} for r in self._rows]
                return DataFrame(sub_rows, columns=key)
            if key in self.columns or any(key in r for r in self._rows):
                return Series([r.get(key, "") for r in self._rows], name=key)
            raise KeyError(key)

        def __setitem__(self, key, value):
            if key not in self.columns:
                self.columns.append(key)
            if isinstance(value, Series) or isinstance(value, list):
                vals = list(value)
                for i, r in enumerate(self._rows):
                    r[key] = vals[i] if i < len(vals) else ""
            else:
                for r in self._rows:
                    r[key] = value

        def iterrows(self):
            for i, r in enumerate(self._rows):
                class RowWrapper:
                    def __init__(self, d):
                        self._d = d

                    def to_dict(self):
                        return dict(self._d)

                    @property
                    def values(self):
                        return list(self._d.values())

                    def items(self):
                        return self._d.items()

                    def keys(self):
                        return self._d.keys()

                    def get(self, k, default=None):
                        return self._d.get(k, default)

                    def __getitem__(self, k):
                        return self._d[k]

                yield i, RowWrapper(r)

        def head(self, n=5):
            return DataFrame(self._rows[:n], columns=self.columns)

        def to_string(self, index=True):
            if not self._rows:
                return "Empty DataFrame"
            lines = [", ".join(self.columns)]
            for r in self._rows[:10]:
                lines.append(", ".join([str(r.get(c, "")) for c in self.columns]))
            return "\n".join(lines)

        def to_csv(self, filepath, index=False):
            with open(filepath, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=self.columns)
                writer.writeheader()
                for r in self._rows:
                    row_clean = {c: r.get(c, "") for c in self.columns}
                    writer.writerow(row_clean)

    def read_csv(filepath, dtype=None, **kwargs):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        rows = []
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            reader = csv.DictReader(f)
            columns = [c.strip() for c in (reader.fieldnames or [])]
            for raw_row in reader:
                cleaned_row = {k.strip(): str(v).strip() for k, v in raw_row.items() if k is not None}
                rows.append(cleaned_row)
        return DataFrame(rows, columns=columns)
