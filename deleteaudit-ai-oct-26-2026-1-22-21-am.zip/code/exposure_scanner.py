import re
from typing import Dict, List, Set, Any
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series
try:
    from .media_reader import MediaReader
except ImportError:
    from media_reader import MediaReader

class ExposureRecord:
    def __init__(self, system_name: str, record_id: str, matched_identifier: str, record_type: str, raw_row: Dict[str, Any]):
        self.system_name = system_name
        self.record_id = record_id
        self.matched_identifier = matched_identifier
        self.record_type = record_type
        self.raw_row = raw_row

    def format_tuple(self) -> str:
        return f"{self.system_name}:{self.record_id}:{self.matched_identifier}:{self.record_type}"

    def __repr__(self):
        return self.format_tuple()

class ExposureScanner:
    """
    Exhaustively scans all storage systems, databases, caches, indices, logs,
    and media files for occurrences of resolved user identifiers.
    """
    def __init__(self, data_loader, media_reader: MediaReader):
        self.loader = data_loader
        self.media_reader = media_reader

    def scan_user(self, user_info: Dict[str, Any]) -> List[ExposureRecord]:
        user_id = user_info["user_id"]
        identifiers = user_info["identifiers"]
        found_records: List[ExposureRecord] = []
        seen_keys: Set[str] = set()

        storage_tables = self.loader.get_storage_tables()
        for table_name in storage_tables:
            df = self.loader.get_table(table_name)
            if df.empty:
                continue

            id_col = self._detect_id_col(df)
            type_col = next((c for c in df.columns if "record_type" in c.lower() or "type" in c.lower()), None)
            sys_col = next((c for c in df.columns if "system" in c.lower()), None)

            # Check if this table has media paths
            path_col = next((c for c in df.columns if "path" in c.lower() or "file" in c.lower()), None)
            text_cache_col = next((c for c in df.columns if "text" in c.lower() or "ocr" in c.lower()), None)

            for _, row in df.iterrows():
                row_dict = row.to_dict()
                rec_id = str(row_dict.get(id_col, "")).strip() if id_col else f"{table_name}_row_{_}"
                rec_type = str(row_dict.get(type_col, table_name)).strip() if type_col else table_name
                system_name = str(row_dict.get(sys_col, table_name)).strip() if sys_col else table_name

                matched_term = None

                # 1. Search all columns in this row
                for col_name, cell_val in row_dict.items():
                    val_str = str(cell_val).strip()
                    if not val_str or val_str.lower() in {"none", "null", "nan"}:
                        continue
                    term = self._match_identifiers(val_str, identifiers)
                    if term:
                        matched_term = term
                        break

                # 2. If media attachment table, also inspect media content
                if not matched_term and path_col:
                    file_path = str(row_dict.get(path_col, "")).strip()
                    fallback_text = str(row_dict.get(text_cache_col, "")).strip() if text_cache_col else ""
                    if file_path or fallback_text:
                        extracted_text = self.media_reader.extract_text(file_path, fallback_text=fallback_text)
                        media_matches = self.media_reader.scan_for_identifiers(extracted_text, identifiers)
                        if media_matches:
                            matched_term = media_matches[0][0]

                if matched_term:
                    unique_key = f"{system_name}:{rec_id}:{matched_term}"
                    if unique_key not in seen_keys:
                        seen_keys.add(unique_key)
                        found_records.append(ExposureRecord(
                            system_name=system_name,
                            record_id=rec_id,
                            matched_identifier=matched_term,
                            record_type=rec_type,
                            raw_row=row_dict
                        ))

        return found_records

    def _detect_id_col(self, df: pd.DataFrame) -> str:
        for col in df.columns:
            cl = col.lower()
            if cl in {"record_id", "id", "ticket_id", "event_id", "snapshot_id", "attachment_id", "log_id", "invoice_id"}:
                return col
        return df.columns[0] if len(df.columns) > 0 else ""

    def _match_identifiers(self, text: str, identifiers: Set[str]) -> str:
        text_lower = text.lower()
        digits_in_text = re.sub(r"[^\d]", "", text)
        stop_words = {"email", "phone", "name", "address", "user_id", "type", "link", "true", "false", "active", "deleted", "usr", "none", "null", "date", "status"}

        for ident in identifiers:
            ident_str = str(ident).strip()
            if not ident_str:
                continue

            ident_lower = ident_str.lower()
            if ident_lower in stop_words or len(ident_lower) < 4:
                continue

            # 1. Email matching
            if "@" in ident_str:
                if ident_lower in text_lower:
                    return ident_str

            # 2. Phone matching (digits)
            elif ident_str.isdigit() and len(ident_str) >= 7:
                if ident_str in digits_in_text:
                    return ident_str

            # 3. User ID or token matching (e.g. USR-101)
            elif re.search(r"usr[-_]\d+", ident_lower):
                pattern = r"(?<![a-zA-Z0-9])" + re.escape(ident_lower) + r"(?![a-zA-Z0-9])"
                if re.search(pattern, text_lower):
                    return ident_str

            # 4. Words, names, usernames, addresses: match with word boundaries
            else:
                pattern = r"\b" + re.escape(ident_lower) + r"\b"
                if re.search(pattern, text_lower):
                    return ident_str

        return ""
