import os
import shutil

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DELETION_RULES_CSV = """rule_id,system_name,record_type,required_action,permitted_identifiers,forbidden_identifiers,is_retention_mandatory,retention_period_days,retention_condition,remediation_phase
RULE-01,primary_db,user_profile,delete,"NONE","email,phone,name,username,address",FALSE,0,none,2
RULE-02,primary_db,user_credentials,delete,"NONE","email,username,password_hash",FALSE,0,none,2
RULE-03,primary_db,user_address,delete,"NONE","street,postal_code,city,phone",FALSE,0,none,2
RULE-04,crm_system,crm_lead,delete,"NONE","email,phone,name,company",FALSE,0,none,2
RULE-05,search_index,search_document,delete,"NONE","email,phone,name,username,alias",FALSE,0,none,2
RULE-06,analytics_dw,event_stream,anonymize,"anonymized_user_token","email,phone,name,user_id",FALSE,90,scrub_direct_identifiers,3
RULE-07,support_system,ticket,redact,"ticket_id","email,phone,name,address",FALSE,30,redact_pii_in_transcript,3
RULE-08,statutory_finance,tax_invoice,retain,"invoice_id,statutory_tax_id,tokenized_id","email,phone,name,address",TRUE,2555,mandatory_tax_code_compliance,5
RULE-09,system_logs,access_log,redact,"session_hash","ip_address,email,user_id",FALSE,14,scrub_query_params,3
RULE-10,backups,snapshot,tombstone_or_expire,"NONE","email,phone,name,user_id",FALSE,30,key_shred_or_tombstone_record,4
RULE-11,media_attachments,document_scan,delete,"NONE","email,phone,name,id_number",FALSE,0,purge_blob_storage,3
"""

DELETION_REQUESTS_CSV = """request_id,user_id,request_date,requested_deletion_type,request_status,submitted_via,reason_category,has_expected_eval,expected_status
DEL-001,USR-101,2026-09-15T08:30:00Z,FULL_ERASURE,SUBMITTED,privacy_portal,gdpr_art_17,TRUE,INCOMPLETE
DEL-002,USR-102,2026-09-18T10:15:00Z,FULL_ERASURE,SUBMITTED,support_ticket,ccpa_erasure,TRUE,COMPLETE
DEL-003,USR-103,2026-09-20T14:00:00Z,FULL_ERASURE,CANCELLED,privacy_portal,user_cancelled,TRUE,NOT_APPLICABLE
DEL-004,USR-104,2026-09-22T09:45:00Z,FULL_ERASURE,SUBMITTED,email_request,gdpr_art_17,TRUE,INCOMPLETE
DEL-005,USR-105,2026-09-25T11:20:00Z,FULL_ERASURE,SUBMITTED,privacy_portal,gdpr_art_17,TRUE,INCOMPLETE
DEL-006,USR-106,2026-09-28T16:10:00Z,FULL_ERASURE,SUBMITTED,mobile_app,gdpr_art_17,TRUE,INCOMPLETE
DEL-007,USR-107,2026-10-01T12:00:00Z,ACCOUNT_CLOSURE,NOT_REQUESTED,customer_support,general_inquiry,TRUE,NOT_APPLICABLE
DEL-008,USR-108,2026-10-05T13:30:00Z,FULL_ERASURE,SUBMITTED,privacy_portal,gdpr_art_17,TRUE,INCOMPLETE
DEL-009,USR-109,2026-10-08T15:45:00Z,FULL_ERASURE,SUBMITTED,privacy_portal,ccpa_erasure,TRUE,COMPLETE
DEL-010,USR-110,2026-10-12T17:00:00Z,FULL_ERASURE,SUBMITTED,privacy_portal,gdpr_art_17,TRUE,INCOMPLETE
"""

USERS_CSV = """user_id,primary_email,phone,full_name,username,registration_date,account_status,has_statutory_tax_records
USR-101,alice.smith@example.com,+1-555-0101,Alice Smith,alicesmith,2023-01-15,PENDING_DELETION,FALSE
USR-102,bob.jones@example.org,+1-555-0102,Bob Jones,bobjones_dev,2022-06-10,DELETED,TRUE
USR-103,charlie.brown@example.net,+1-555-0103,Charlie Brown,charlieb,2024-02-01,ACTIVE,FALSE
USR-104,diana.prince@example.com,+1-555-0104,Diana Prince,dianap,2021-11-20,PENDING_DELETION,FALSE
USR-105,evan.wright@example.io,+1-555-0105,Evan Wright,evanw,2023-08-04,PENDING_DELETION,TRUE
USR-106,fiona.gallagher@example.com,+1-555-0106,Fiona Gallagher,fionag,2022-03-12,PENDING_DELETION,TRUE
USR-107,george.clark@example.com,+1-555-0107,George Clark,georgec,2024-05-19,ACTIVE,FALSE
USR-108,hannah.abbott@example.co.uk,+1-555-0108,Hannah Abbott,habbott,2023-09-01,PENDING_DELETION,FALSE
USR-109,ian.malcolm@example.org,+1-555-0109,Ian Malcolm,ianm_chaos,2021-04-14,DELETED,TRUE
USR-110,julia.roberts@example.net,+1-555-0110,Julia Roberts,jroberts_sky,2022-12-05,PENDING_DELETION,FALSE
"""

IDENTITY_LINKS_CSV = """link_id,user_id,link_type,identifier_type,identifier_value,confidence,verified_date
LINK-001,USR-101,ACCOUNT_MERGE,email,alice.smith@work.com,1.0,2024-01-10
LINK-002,USR-101,HISTORICAL_PHONE,phone,+1-555-9988,0.95,2023-01-15
LINK-003,USR-102,HISTORICAL_EMAIL,email,bob.jones.old@domain.net,1.0,2022-06-10
LINK-004,USR-104,SECONDARY_EMAIL,email,diana.alt@hero.org,1.0,2022-05-12
LINK-005,USR-105,HISTORICAL_ADDRESS,address,742 Evergreen Terrace,0.9,2023-08-04
LINK-006,USR-106,ALIAS,username,fiona_g_rock,1.0,2022-03-12
LINK-007,USR-108,SECONDARY_PHONE,phone,+44-7700-900108,1.0,2023-09-01
LINK-008,USR-109,HISTORICAL_EMAIL,email,ian.malcolm@dinotech.org,1.0,2021-04-14
LINK-009,USR-110,EMAIL_PLUS_TAG,email,julia+newsletter@example.net,1.0,2023-03-22
LINK-010,USR-110,ALIAS,username,jules_tech,1.0,2022-12-05
"""

PRIMARY_DATABASE_CSV = """record_id,user_id,system_name,record_type,content_payload,treatment_status,last_updated
PDB-103,USR-103,primary_db,user_profile,"name:Charlie Brown, email:charlie.brown@example.net",ACTIVE,2024-02-01
PDB-107,USR-107,primary_db,user_profile,"name:George Clark, email:george.clark@example.com",ACTIVE,2024-05-19
"""

CRM_SYSTEM_CSV = """record_id,system_name,record_type,lead_email,contact_phone,account_name,status
CRM-101,crm_system,crm_lead,alice.smith@work.com,+1-555-9988,Acme Corp Enterprise,ACTIVE_LEAD
CRM-107,crm_system,crm_lead,george.clark@example.com,+1-555-0107,Clark Innovations,PROSPECT
CRM-999,crm_system,crm_lead,unrelated.user@other.com,+1-555-9999,Global Logistics,QUALIFIED
"""

SEARCH_INDEX_CSV = """record_id,system_name,record_type,indexed_identifier,document_tags,indexed_at
SRCH-103,search_index,search_document,charlie.brown@example.net,"developer,active",2024-02-01
SRCH-107,search_index,search_document,george.clark@example.com,"enterprise,sales",2024-05-19
SRCH-110,search_index,search_document,julia+newsletter@example.net,"alias:jules_tech,subscriber",2023-03-22
"""

ANALYTICS_DW_CSV = """event_id,system_name,record_type,user_identifier,is_anonymized,event_type,timestamp
EVT-102,analytics_dw,event_stream,ANON-TOK-88219,TRUE,PAGE_VIEW,2026-09-18T10:20:00Z
EVT-103,analytics_dw,event_stream,charlie.brown@example.net,FALSE,LOGIN_SUCCESS,2026-09-20T14:10:00Z
EVT-107,analytics_dw,event_stream,george.clark@example.com,FALSE,BUTTON_CLICK,2026-10-01T12:05:00Z
EVT-109,analytics_dw,event_stream,ANON-TOK-44192,TRUE,PURCHASE,2026-10-08T15:50:00Z
"""

STATUTORY_FINANCE_CSV = """record_id,system_name,record_type,associated_user_id,invoice_id,statutory_tax_id,permitted_token,raw_pii_content,retention_status
INV-102,statutory_finance,tax_invoice,USR-102,INV-2022-9912,TAX-US-99128,TOK-BOB-99,NONE,PROPERLY_MASKED
INV-105,statutory_finance,tax_invoice,USR-105,INV-2023-5541,TAX-US-55410,TOK-EVAN-55,"email:evan.wright@example.io,address:742 Evergreen Terrace",FORBIDDEN_PII_PRESENT
INV-109,statutory_finance,tax_invoice,USR-109,INV-2021-3319,TAX-US-33192,CUST-TOKEN-883,NONE,PROPERLY_MASKED
"""

SUPPORT_SYSTEM_CSV = """ticket_id,system_name,record_type,associated_user_id,customer_identifier,transcript_snippet,is_pii_redacted
TCK-102,support_system,ticket,USR-102,REDACTED_USER,"Customer reported subscription inquiry. [PII REDACTED PER GDPR POLICY]",TRUE
TCK-103,support_system,ticket,USR-103,charlie.brown@example.net,"Customer Charlie Brown asking about billing cycle renewal.",FALSE
TCK-107,support_system,ticket,USR-107,george.clark@example.com,"George Clark enterprise pricing demo scheduled.",FALSE
TCK-109,support_system,ticket,USR-109,REDACTED_USER,"Customer inquired regarding Jurassic research trial. [REDACTED]",TRUE
"""

SYSTEM_LOGS_CSV = """log_id,system_name,record_type,request_path,session_hash,raw_query_params,timestamp
LOG-102,system_logs,access_log,/api/v1/profile,SESS_HASH_99120,NONE,2026-09-18T10:14:00Z
LOG-103,system_logs,access_log,/api/v1/feed,SESS_HASH_44122,email=charlie.brown%40example.net,2026-09-20T13:50:00Z
LOG-107,system_logs,access_log,/api/v1/dashboard,SESS_HASH_77189,email=george.clark%40example.com,2026-10-01T11:55:00Z
LOG-109,system_logs,access_log,/api/v1/logout,SESS_HASH_33118,NONE,2026-10-08T15:40:00Z
"""

BACKUPS_CSV = """snapshot_id,system_name,record_type,snapshot_date,associated_user_ids,key_shred_status,tombstone_applied
SNAP-102,backups,snapshot,2026-09-17,USR-102,SHREDDED,TRUE
SNAP-108,backups,snapshot,2026-10-04,USR-108,ACTIVE_KEY,FALSE
SNAP-109,backups,snapshot,2026-10-07,USR-109,SHREDDED,TRUE
"""

SYNC_JOBS_CSV = """process_id,process_name,process_type,source_system,target_system,frequency_cron,is_active,filter_deleted_users,last_run_timestamp
SYNC-01,crm_to_primary_lead_sync,SYNC_JOB,crm_system,primary_db,"0 * * * *",TRUE,FALSE,2026-10-24T20:00:00Z
SYNC-02,dw_aggregation_pipeline,BATCH_PIPELINE,primary_db,analytics_dw,"0 0 * * *",TRUE,TRUE,2026-10-24T00:00:00Z
JOB-03,nightly_staging_restore,RESTORE_JOB,backups,primary_db,"30 2 * * *",TRUE,FALSE,2026-10-24T02:30:00Z
JOB-04,search_index_rebuild,IMPORT_JOB,primary_db,search_index,"0 4 * * 0",FALSE,TRUE,2026-10-18T04:00:00Z
JOB-05,statutory_compliance_archive,ARCHIVE_JOB,statutory_finance,cold_vault,"0 1 1 * *",TRUE,TRUE,2026-10-01T01:00:00Z
"""

MEDIA_ATTACHMENTS_CSV = """attachment_id,system_name,record_type,associated_user_id,file_path,file_type,status,extracted_text_cache
DOC-104,media_attachments,document_scan,USR-104,dataset/media/id_scan_usr104.txt,TXT,ACTIVE,"PASSPORT / NATIONAL ID VERIFICATION: Full Name: Diana Prince, Phone: +1-555-0104, Email: diana.alt@hero.org, Address: Themyscira Embassy, Washington DC. Verified by KYC Agent on 2021-11-20."
DOC-107,media_attachments,document_scan,USR-107,dataset/media/kyc_george.txt,TXT,ACTIVE,"DRIVER LICENSE VERIFICATION: George Clark, Phone: +1-555-0107, Address: 100 Main St, Austin TX."
"""

ID_SCAN_USR104_TXT = """PASSPORT / NATIONAL ID VERIFICATION:
Full Name: Diana Prince
Phone: +1-555-0104
Email: diana.alt@hero.org
Address: Themyscira Embassy, Washington DC
Verified by KYC Agent on 2021-11-20
Status: ACTIVE_DOCUMENT_ARCHIVE
"""

FILES = {
    "deletion_rules.csv": DELETION_RULES_CSV,
    "deletion_requests.csv": DELETION_REQUESTS_CSV,
    "users.csv": USERS_CSV,
    "identity_links.csv": IDENTITY_LINKS_CSV,
    "primary_database.csv": PRIMARY_DATABASE_CSV,
    "crm_system.csv": CRM_SYSTEM_CSV,
    "search_index.csv": SEARCH_INDEX_CSV,
    "analytics_dw.csv": ANALYTICS_DW_CSV,
    "statutory_finance.csv": STATUTORY_FINANCE_CSV,
    "support_system.csv": SUPPORT_SYSTEM_CSV,
    "system_logs.csv": SYSTEM_LOGS_CSV,
    "backups.csv": BACKUPS_CSV,
    "sync_jobs.csv": SYNC_JOBS_CSV,
    "media_attachments.csv": MEDIA_ATTACHMENTS_CSV,
}

def seed_directories():
    for folder in ["dataset", "data"]:
        folder_path = os.path.join(BASE_DIR, folder)
        media_path = os.path.join(folder_path, "media")
        os.makedirs(media_path, exist_ok=True)
        
        for fname, content in FILES.items():
            fpath = os.path.join(folder_path, fname)
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(content.strip() + "\n")
                
        with open(os.path.join(media_path, "id_scan_usr104.txt"), "w", encoding="utf-8") as f:
            f.write(ID_SCAN_USR104_TXT.strip() + "\n")
            
    print("[SEED] Successfully seeded dataset/ and data/ directories.")

if __name__ == "__main__":
    seed_directories()
