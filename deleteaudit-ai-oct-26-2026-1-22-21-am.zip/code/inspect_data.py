import os
import glob
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series

def inspect_datasets():
    print("=" * 80)
    print("DATASET & DATA DIRECTORY INSPECTION REPORT")
    print("=" * 80)
    
    data_dir = "dataset" if os.path.exists("dataset") else "data"
    csv_files = sorted(glob.glob(os.path.join(data_dir, "*.csv")))
    
    summary = []
    
    for fpath in csv_files:
        fname = os.path.basename(fpath)
        try:
            df = pd.read_csv(fpath)
            row_count, col_count = df.shape
            cols = list(df.columns)
            print(f"\n--- FILE: {fname} (Rows: {row_count}, Columns: {col_count}) ---")
            print(f"Columns: {', '.join(cols)}")
            print("Sample Rows (first 2):")
            print(df.head(2).to_string(index=False))
            summary.append({
                "file": fname,
                "rows": row_count,
                "cols": cols
            })
        except Exception as e:
            print(f"Error reading {fpath}: {e}")
            
    # Check media attachments
    media_dir = os.path.join(data_dir, "media")
    if os.path.exists(media_dir):
        media_files = os.listdir(media_dir)
        print(f"\n--- MEDIA ATTACHMENTS DIRECTORY: {media_dir} (Files: {len(media_files)}) ---")
        for mf in media_files:
            mpath = os.path.join(media_dir, mf)
            sz = os.path.getsize(mpath)
            print(f" - {mf} ({sz} bytes)")
            if mf.endswith(".txt"):
                with open(mpath, "r", encoding="utf-8") as f:
                    snippet = f.read(150).replace("\n", " ")
                    print(f"   Preview: {snippet}...")
                    
    # Log to log.txt
    log_msg = f"[INSPECTION_COMPLETE] Inspected {len(csv_files)} CSV datasets in {data_dir}/\n"
    with open("log.txt", "a", encoding="utf-8") as log_f:
        log_f.write(log_msg)
        
    print("\n" + "=" * 80)
    print("SYSTEM ENTITY RELATIONSHIP SUMMARY:")
    print("1. 'users.csv' (Key: user_id) defines core registered identities, emails, phones.")
    print("2. 'identity_links.csv' (Foreign Key: user_id) maps aliases, secondary emails, merged accounts, +tag emails, phone history.")
    print("3. 'deletion_requests.csv' (Foreign Key: user_id) records erasure requests, request status, and evaluation ground truth.")
    print("4. 'deletion_rules.csv' (Composite Key: system_name, record_type) specifies required action (delete/redact/anonymize/retain), permitted/forbidden identifiers, and statutory retention.")
    print("5. Storage Stores: 'primary_database.csv', 'crm_system.csv', 'search_index.csv', 'analytics_dw.csv', 'statutory_finance.csv', 'support_system.csv', 'system_logs.csv', 'backups.csv', 'media_attachments.csv'.")
    print("6. Process Pipeline: 'sync_jobs.csv' tracks active replication, sync, and restore processes connecting sources to targets.")
    print("=" * 80)

if __name__ == "__main__":
    inspect_datasets()
