import os
import sys
import datetime
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series
from typing import Dict, List, Any

# Ensure code dir and project root are in sys.path
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

try:
    from .config import (
        DATASET_DIR, OUTPUT_CSV_PATH, LOG_PATH, EXPECTED_OUTPUT_COLUMNS, ALLOWED_STATUSES
    )
    from .loader import DataLoader
    from .identity_resolver import IdentityResolver
    from .media_reader import MediaReader
    from .exposure_scanner import ExposureScanner
    from .rules_engine import RulesEngine
    from .recreation_analyzer import RecreationPathAnalyzer
    from .remediation_planner import RemediationPlanner
    from .llm_client import LLMExplanationSynthesizer
except ImportError:
    from config import (
        DATASET_DIR, OUTPUT_CSV_PATH, LOG_PATH, EXPECTED_OUTPUT_COLUMNS, ALLOWED_STATUSES
    )
    from loader import DataLoader
    from identity_resolver import IdentityResolver
    from media_reader import MediaReader
    from exposure_scanner import ExposureScanner
    from rules_engine import RulesEngine
    from recreation_analyzer import RecreationPathAnalyzer
    from remediation_planner import RemediationPlanner
    from llm_client import LLMExplanationSynthesizer

def log_transcript(message: str):
    timestamp = datetime.datetime.utcnow().isoformat() + "Z"
    entry = f"[{timestamp}] {message}\n"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception as e:
        print(f"[WARN] Failed to write log: {e}")

class DeletionAuditAgent:
    """
    Autonomous Deletion Audit Agent.
    Evaluates corporate data stores, resolves identity graph closures,
    detects policy violations and recreation paths, and synthesizes ordered remediations.
    """
    def __init__(self, dataset_dir: str = DATASET_DIR):
        self.dataset_dir = dataset_dir
        self.loader = DataLoader(dataset_dir)
        self.users_df = self.loader.get_table("users")
        self.links_df = self.loader.get_table("identity_links")
        self.rules_df = self.loader.get_rules()
        self.requests_df = self.loader.get_requests()
        
        self.identity_resolver = IdentityResolver(self.users_df, self.links_df)
        self.media_reader = MediaReader()
        self.exposure_scanner = ExposureScanner(self.loader, self.media_reader)
        self.rules_engine = RulesEngine(self.rules_df, self.loader)
        self.recreation_analyzer = RecreationPathAnalyzer(self.loader)
        self.remediation_planner = RemediationPlanner()
        self.llm_synthesizer = LLMExplanationSynthesizer()

    def audit_all(self, output_path: str = OUTPUT_CSV_PATH) -> pd.DataFrame:
        log_transcript(f"[AUDIT_BATCH_START] Beginning batch deletion audit for {len(self.requests_df)} requests.")
        results: List[Dict[str, Any]] = []

        for idx, req_row in self.requests_df.iterrows():
            req_dict = req_row.to_dict()
            res = self.audit_request(req_dict)
            results.append(res)
            log_transcript(f"[AUDIT_RECORD] Request {res['request_id']} (User {res['user_id']}) -> Status: {res['status']}, Exposing: {res['exposing_records']}, Recreation: {res['recreation_processes']}")

        out_df = pd.DataFrame(results)
        # Validate columns
        for col in EXPECTED_OUTPUT_COLUMNS:
            if col not in out_df.columns:
                out_df[col] = ""
        out_df = out_df[EXPECTED_OUTPUT_COLUMNS]

        # Validate enums
        invalid_statuses = out_df[~out_df["status"].isin(ALLOWED_STATUSES)]
        if not invalid_statuses.empty:
            raise ValueError(f"Found invalid status values in output: {invalid_statuses['status'].tolist()}")

        out_df.to_csv(output_path, index=False)
        log_transcript(f"[AUDIT_BATCH_COMPLETE] Generated {output_path} with {len(out_df)} audited rows.")
        return out_df

    def audit_request(self, req_dict: Dict[str, Any]) -> Dict[str, Any]:
        req_id = str(req_dict.get("request_id", "")).strip()
        user_id = str(req_dict.get("user_id", "")).strip()
        req_status = str(req_dict.get("request_status", "")).strip().upper()

        # Step 1: Check applicability
        # A deletion request is NOT_APPLICABLE if user never requested deletion,
        # or status was cancelled, withdrawn, or general inquiry only.
        is_applicable = (
            req_status not in {"CANCELLED", "WITHDRAWN", "NOT_REQUESTED", "INQUIRY_ONLY", ""} and
            str(req_dict.get("requested_deletion_type", "")).strip().upper() in {"FULL_ERASURE", "PARTIAL_ERASURE", "ACCOUNT_DELETION"}
        )

        if not is_applicable:
            plan = self.remediation_planner.generate_plan("NOT_APPLICABLE", user_id, [], [])
            explanation = self.llm_synthesizer.generate_explanation(req_id, user_id, "NOT_APPLICABLE", [], [], req_dict)
            return {
                "request_id": req_id,
                "user_id": user_id,
                "status": "NOT_APPLICABLE",
                "exposing_records": "NONE",
                "recreation_processes": "NONE",
                "remediation_steps": "; ".join(plan),
                "explanation": explanation
            }

        # Step 2: Resolve user identifier graph
        user_info = self.identity_resolver.resolve_user_identifiers(user_id)

        # Step 3: Scan all storage stores & media for exposed identifiers
        raw_exposures = self.exposure_scanner.scan_user(user_info)

        # Step 4: Evaluate compliance against deletion rules
        violations = self.rules_engine.evaluate_violations(user_info, raw_exposures)

        # Step 5: Analyze recreation paths
        recreation_procs = self.recreation_analyzer.analyze_recreation_vectors(user_info, violations)

        # Step 6: Deterministic decision logic
        # A deletion is COMPLETE only if ALL hold:
        # - every relevant copy received treatment required by deletion_rules.csv (violations == 0)
        # - no active sync/import/restore path can recreate data (recreation_procs == 0)
        # - retained records contain only identifiers rules permit
        # - records the policy requires to be retained still exist
        if len(violations) == 0 and len(recreation_procs) == 0:
            final_status = "COMPLETE"
        else:
            final_status = "INCOMPLETE"

        # Step 7: Ordered remediation steps
        ordered_steps = self.remediation_planner.generate_plan(final_status, user_id, violations, recreation_procs)

        # Format exposing records
        if violations:
            exposing_str = "; ".join([v.format_tuple() for v in violations])
        else:
            exposing_str = "NONE"

        # Format recreation processes
        if recreation_procs:
            recreation_str = "; ".join([p.format_tuple() for p in recreation_procs])
        else:
            recreation_str = "NONE"

        explanation = self.llm_synthesizer.generate_explanation(
            req_id, user_id, final_status, violations, recreation_procs, req_dict
        )

        return {
            "request_id": req_id,
            "user_id": user_id,
            "status": final_status,
            "exposing_records": exposing_str,
            "recreation_processes": recreation_str,
            "remediation_steps": "; ".join(ordered_steps),
            "explanation": explanation
        }

if __name__ == "__main__":
    agent = DeletionAuditAgent()
    out_df = agent.audit_all()
    print("=" * 80)
    print("DELETION AUDIT COMPLETED. OUTPUT PREVIEW:")
    print("=" * 80)
    print(out_df[["request_id", "user_id", "status", "exposing_records", "recreation_processes"]].to_string())
