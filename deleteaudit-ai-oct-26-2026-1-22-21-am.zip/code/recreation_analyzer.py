from typing import Dict, List, Set, Any
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series
try:
    from .rules_engine import RuleViolation
except ImportError:
    from rules_engine import RuleViolation

class RecreationProcess:
    def __init__(self, process_id: str, process_name: str, process_type: str, source_system: str, target_system: str, reason: str):
        self.process_id = process_id
        self.process_name = process_name
        self.process_type = process_type
        self.source_system = source_system
        self.target_system = target_system
        self.reason = reason

    def format_tuple(self) -> str:
        return f"{self.process_id}:{self.source_system}->{self.target_system}"

    def __repr__(self):
        return self.format_tuple()

class RecreationPathAnalyzer:
    """
    Analyzes automated data syncs, scheduled ETL jobs, and backup restore pipelines
    to identify active vectors capable of resurrecting deleted data into operational stores.
    """
    def __init__(self, data_loader):
        self.loader = data_loader

    def analyze_recreation_vectors(self, user_info: Dict[str, Any], violations: List[RuleViolation]) -> List[RecreationProcess]:
        recreation_vectors: List[RecreationProcess] = []
        sync_df = self.loader.get_table("sync_jobs")
        if sync_df.empty:
            return recreation_vectors

        # Systems that have untreated/exposing records for this user
        exposing_sources = {v.system_name for v in violations}
        user_id = user_info["user_id"]

        for _, row in sync_df.iterrows():
            row_dict = row.to_dict()
            pid = str(row_dict.get("process_id", "")).strip()
            pname = str(row_dict.get("process_name", "")).strip()
            ptype = str(row_dict.get("process_type", "")).strip()
            source = str(row_dict.get("source_system", "")).strip()
            target = str(row_dict.get("target_system", "")).strip()
            is_active = str(row_dict.get("is_active", "")).strip().lower() in {"true", "1", "yes"}
            filter_deleted = str(row_dict.get("filter_deleted_users", "")).strip().lower() in {"true", "1", "yes"}

            if not is_active:
                continue

            # Only processes targeting operational stores can recreate active user data
            operational_targets = {"primary_db", "crm_system", "search_index", "staging_db", "operational_db"}
            if target not in operational_targets:
                continue

            # Vector Condition 1: Source system contains exposing records and does not filter deleted users
            if source in exposing_sources and not filter_deleted:
                recreation_vectors.append(RecreationProcess(
                    process_id=pid,
                    process_name=pname,
                    process_type=ptype,
                    source_system=source,
                    target_system=target,
                    reason=f"Active job '{pname}' synchronizes from {source} (which still holds untreated records) into operational {target} without filtering deleted records."
                ))

            # Vector Condition 2: Scheduled restore or replication job from backups/archives lacking deleted-user filtering
            elif source in {"backups", "cold_vault", "archive"} and not filter_deleted:
                backups_df = self.loader.get_table("backups")
                has_backup = False
                if not backups_df.empty:
                    for _, b_row in backups_df.iterrows():
                        row_txt = " ".join([str(v) for v in b_row.values]).lower()
                        if user_id.lower() in row_txt:
                            # If snapshot is not key-shredded
                            if str(b_row.get("key_shred_status", "")).upper() != "SHREDDED":
                                has_backup = True
                                break
                if has_backup:
                    recreation_vectors.append(RecreationProcess(
                        process_id=pid,
                        process_name=pname,
                        process_type=ptype,
                        source_system=source,
                        target_system=target,
                        reason=f"Active restore process '{pname}' restores un-shredded snapshots from {source} into operational {target} without filtering deleted users."
                    ))

        return recreation_vectors
