import os
import glob
try:
    import pandas as pd
except ImportError:
    try:
        from .compat_pandas import DataFrame, read_csv, Series
    except ImportError:
        from compat_pandas import DataFrame, read_csv, Series
    class pd:
        DataFrame = DataFrame
        read_csv = staticmethod(read_csv)
        Series = Series
from typing import Dict, Any, List

class DataLoader:
    """
    Dynamic loader for corporate data exports, policies, requests, and multimedia attachments.
    Never hardcodes table names or user lists.
    """
    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        self.tables: Dict[str, pd.DataFrame] = {}
        self.media_files: Dict[str, str] = {}
        self.load_all()

    def load_all(self):
        if not os.path.isdir(self.dataset_dir):
            try:
                try:
                    from .seed_data import seed_directories
                except ImportError:
                    from seed_data import seed_directories
                seed_directories()
            except Exception as e:
                print(f"[WARN] Auto-seed failed: {e}")

        if not os.path.isdir(self.dataset_dir):
            raise FileNotFoundError(f"Dataset directory '{self.dataset_dir}' does not exist.")

        # Load all CSVs
        csv_files = glob.glob(os.path.join(self.dataset_dir, "*.csv"))
        for csv_path in csv_files:
            table_name = os.path.splitext(os.path.basename(csv_path))[0]
            try:
                # Read CSV with pandas, treating empty strings as empty
                df = pd.read_csv(csv_path, dtype=str).fillna("")
                # Clean column headers
                df.columns = [c.strip() for c in df.columns]
                self.tables[table_name] = df
            except Exception as e:
                print(f"[WARN] Failed to load CSV '{csv_path}': {e}")

        # Scan media attachments directory if present
        media_dir = os.path.join(self.dataset_dir, "media")
        if os.path.isdir(media_dir):
            for fname in os.listdir(media_dir):
                fpath = os.path.join(media_dir, fname)
                if os.path.isfile(fpath):
                    self.media_files[fname] = fpath

    def get_table(self, table_name: str) -> pd.DataFrame:
        return self.tables.get(table_name, pd.DataFrame())

    def get_rules(self) -> pd.DataFrame:
        return self.get_table("deletion_rules")

    def get_requests(self) -> pd.DataFrame:
        return self.get_table("deletion_requests")

    def get_storage_tables(self) -> List[str]:
        """
        Returns all storage store tables (excluding policy rules, requests, and identity registries).
        """
        excluded = {"deletion_rules", "deletion_requests", "identity_links", "users"}
        return [t for t in self.tables.keys() if t not in excluded]
