import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  signInAnonymously
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: 'auditor' | 'admin' | 'viewer';
  createdAt: string;
  lastLoginAt: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signInGoogle: () => Promise<void>;
  signInAsGuest: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  signInGoogle: async () => {},
  signInAsGuest: async () => {},
  logout: async () => {}
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync user profile with Firestore
  const syncProfile = async (firebaseUser: User) => {
    try {
      const userRef = doc(db, 'users', firebaseUser.uid);
      const snap = await getDoc(userRef);
      const now = new Date().toISOString();

      if (!snap.exists()) {
        const newProfile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || `${firebaseUser.uid.slice(0, 8)}@auditor.internal`,
          displayName: firebaseUser.displayName || 'Compliance Auditor',
          photoURL: firebaseUser.photoURL || '',
          role: 'auditor',
          createdAt: now,
          lastLoginAt: now
        };
        await setDoc(userRef, newProfile);
        setProfile(newProfile);
      } else {
        const existing = snap.data() as UserProfile;
        const updated = { ...existing, lastLoginAt: now };
        await setDoc(userRef, updated, { merge: true });
        setProfile(updated);
      }
    } catch (err) {
      console.warn('Profile sync notice:', err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await syncProfile(currentUser);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error('Google Sign-in notice:', error);
      if (error?.code === 'auth/popup-blocked') {
        throw new Error('Sign-in popup was blocked by browser. Please allow popups for this site.');
      } else if (error?.code === 'auth/cancelled-popup-request') {
        return;
      }
      throw error;
    }
  };

  const signInAsGuest = async () => {
    try {
      await signInAnonymously(auth);
    } catch (error: any) {
      if (
        error?.code === 'auth/admin-restricted-operation' ||
        error?.code === 'auth/operation-not-allowed' ||
        error?.message?.includes('admin-restricted-operation')
      ) {
        console.info('Firebase Anonymous Auth is restricted by admin policy. Activating local guest auditor session.');
        const guestUid = 'guest-auditor-session';
        const guestUser = {
          uid: guestUid,
          email: 'guest.auditor@internal.compliance',
          displayName: 'Guest Compliance Auditor',
          photoURL: '',
          isAnonymous: true,
        } as unknown as User;

        const guestProfile: UserProfile = {
          uid: guestUid,
          email: 'guest.auditor@internal.compliance',
          displayName: 'Guest Compliance Auditor',
          photoURL: '',
          role: 'auditor',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
        };

        setUser(guestUser);
        setProfile(guestProfile);
        return;
      }
      console.error('Guest Sign-in error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      if (auth.currentUser) {
        await signOut(auth);
      }
      setUser(null);
      setProfile(null);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInGoogle, signInAsGuest, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
