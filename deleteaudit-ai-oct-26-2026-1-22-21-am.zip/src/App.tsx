import { AuthProvider } from './context/AuthContext';
import AuditApp from '../code/ui/AuditApp';

export default function App() {
  return (
    <AuthProvider>
      <AuditApp />
    </AuthProvider>
  );
}
