import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './firebase';

export interface AuditNote {
  noteId: string;
  requestId: string;
  targetUserId: string;
  auditorUid: string;
  auditorEmail: string;
  noteText: string;
  statusOverride?: 'PENDING_REVIEW' | 'CERTIFIED_ERASED' | 'EXCEPTION_FLAGGED';
  createdAt: string;
}

// Local store fallback for guest testing sessions
const guestNotesStore: Record<string, AuditNote[]> = {};

export function subscribeToAuditNotes(
  userId: string,
  requestId: string,
  onUpdate: (notes: AuditNote[]) => void
) {
  if (!userId) return () => {};

  if (userId === 'guest-auditor-session') {
    const list = (guestNotesStore[requestId] || []).slice();
    list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    onUpdate(list);
    return () => {};
  }

  const notesRef = collection(db, 'users', userId, 'auditNotes');
  const q = query(notesRef, where('requestId', '==', requestId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: AuditNote[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as AuditNote);
      });
      items.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      onUpdate(items);
    },
    (error) => {
      console.warn('Audit notes listener notice:', error);
      onUpdate([]);
    }
  );
}

export async function saveAuditNote(
  userId: string,
  note: Omit<AuditNote, 'noteId' | 'createdAt'> & { noteId?: string }
): Promise<string> {
  const noteId = note.noteId || `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();

  const fullNote: AuditNote = {
    ...note,
    noteId,
    createdAt: now
  };

  if (userId === 'guest-auditor-session') {
    if (!guestNotesStore[note.requestId]) {
      guestNotesStore[note.requestId] = [];
    }
    guestNotesStore[note.requestId].push(fullNote);
    return noteId;
  }

  const noteDoc = doc(db, 'users', userId, 'auditNotes', noteId);
  await setDoc(noteDoc, fullNote);
  return noteId;
}

export async function removeAuditNote(userId: string, noteId: string): Promise<void> {
  if (userId === 'guest-auditor-session') {
    for (const reqId in guestNotesStore) {
      guestNotesStore[reqId] = guestNotesStore[reqId].filter((n) => n.noteId !== noteId);
    }
    return;
  }
  const noteDoc = doc(db, 'users', userId, 'auditNotes', noteId);
  await deleteDoc(noteDoc);
}
